import os
import glob
import time
import random
import argparse
from traceback import print_tb
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from tqdm import tqdm

import sys
import os
# 获取上一级目录的路径
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, parent_dir)

from utils_general import load_data_general
from utils_general import normalization, renormalization, sample_batch_index, uniform_sampler, binary_sampler, rounding, MAE, RMSE
import time

class Generator(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(Generator, self).__init__()

        self.Encoder = nn.Sequential(
            nn.Linear(in_channels, hidden_channels),
            nn.ReLU(),
            nn.Linear(hidden_channels, hidden_channels),
            nn.ReLU(),
            nn.Linear(hidden_channels, hidden_channels*2),
            nn.Sigmoid()
        )

        self.Decoder = nn.Sequential(
            nn.Linear(hidden_channels, hidden_channels),
            nn.ReLU(),
            nn.Linear(hidden_channels, hidden_channels),
            nn.ReLU(),
            nn.Linear(hidden_channels, out_channels),
            nn.Sigmoid()
        )

        self.fc_m = nn.Linear(hidden_channels, hidden_channels)
        self.fc_sigma = nn.Linear(hidden_channels, hidden_channels)
  
    def reparameterise(self, mu, logvar):
        epsilon = torch.randn_like(mu)
        return mu + epsilon * torch.exp(logvar / 2)

# based on implementation of GAIN and material "https://adaning.github.io/posts/9047.html"
    def forward(self, x, m):
        inputs = torch.cat([x, m], axis = 1)
        
        code = self.Encoder(inputs)

        mu, logvar = code.chunk(2, dim=1)
        z = self.reparameterise(mu, logvar)
        recon_x = self.Decoder(z)

        return recon_x, mu, logvar
        
class Discriminator(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(Discriminator, self).__init__()

        self.w_1 = nn.Linear(in_channels, hidden_channels)
        self.w_2 = nn.Linear(hidden_channels, hidden_channels)
        self.w_3 = nn.Linear(hidden_channels, out_channels)
        self.relu = nn.ReLU()
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x, h):
        inputs = torch.cat([x, h], axis = 1)
        D_h1 = self.relu(self.w_1(inputs))
        D_h2 = self.relu(self.w_2(D_h1))
        Mask_prob = self.sigmoid(self.w_3(D_h2))

        return Mask_prob
    

def loss_computation(M, X, G_sample, Mask_prob, alpha, mu, logvar):
    # mse loss
    loss_mse = torch.mean((M * X - M * G_sample)**2) / torch.mean(M)*1000

    # discriminator loss
    loss_discriminator = -torch.mean(M * torch.log(Mask_prob + 1e-8) + (1-M) * torch.log(1. - Mask_prob + 1e-8))

    # KL loss
    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    
    # reconstruction loss
    recon_loss = F.binary_cross_entropy(M*G_sample, M*X)

    return alpha*loss_mse  + loss_discriminator + 0.1*(kl_loss + recon_loss)
    

def parse_args():
    parser = argparse.ArgumentParser(description='Dual enhanced dbnn for missing data imputation')
    parser.add_argument('--no-cuda', action='store_true', default=False, help='Disables CUDA training.')
    parser.add_argument('--fastmode', action='store_true', default=False, help='Validate during training pass.')
    parser.add_argument('--seed', type=int, default=1234, help='Random seed.')
    parser.add_argument('--epochs', type=int, default=10000, help='Number of epochs to train.')
    parser.add_argument('--lr', type=float, default=0.0010, help='Initial learning rate.')
    parser.add_argument('--weight_decay', type=float, default=2e-4, help='Weight decay (L2 loss on parameters).')
    parser.add_argument("--missing_mechanism", type=str, default="MCAR")
    parser.add_argument('--hidden', type=int, default=8, help='Number of hidden units.')
    parser.add_argument('--data_name', default='wine', type=str)
    parser.add_argument('--miss_rate', help='missing data probability', default=0.2, type=float)
    parser.add_argument('--batch_size', help='the number of samples in mini-batch', default=64, type=int)
    parser.add_argument('--hint_rate', help='hint probability', default=0.9, type=float)
    parser.add_argument('--alpha_mse', help='mse proportion in the final loss', default=100, type=float)
    parser.add_argument('--gpuid', choices=['0','1'], default='0', type=str)

    return parser.parse_args()



def main(args):
    
    # print(args)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    args.cuda = not args.no_cuda and torch.cuda.is_available()
    if args.cuda:
        torch.cuda.manual_seed(args.seed)
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    ori_data_x, data_x, data_m = load_data_general(args.data_name, args.miss_rate, missing_mechanism=args.missing_mechanism)

    norm_data, norm_parameters = normalization(data_x)
    norm_data_x = np.nan_to_num(norm_data, 0)

    no, dim = data_x.shape
    
    # Hidden state dimensions
    h_dim = int(dim)  
    
    # Normalization

    
    generator = Generator(2*dim, h_dim, dim).to(device)
    discriminator = Discriminator(2*dim, h_dim, dim).to(device)

    optimizer_G = torch.optim.Adam(generator.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    # print('\n##### Start training...')
    
    start = time.time()

    # for epoch in tqdm(range(args.epochs)):
    for epoch in range(args.epochs):
        generator.train()
        optimizer_G.zero_grad()

        batch_size = args.batch_size
        batch_idx = sample_batch_index(no, batch_size)

        X_mb = norm_data_x[batch_idx, :]  
        M_mb = data_m[batch_idx, :]  
        Z_mb = uniform_sampler(0, 0.01, batch_size, dim)
        X_mb = M_mb * X_mb + (1-M_mb) * Z_mb

        H_mb_temp = binary_sampler(args.hint_rate, batch_size, dim)
        H_mb = M_mb * H_mb_temp

        G_sample, mu, logvar = generator.forward(torch.Tensor(X_mb).to(device), torch.Tensor(M_mb).to(device))
        Hat_X = X_mb * M_mb + G_sample.cpu().detach().numpy() * (1-M_mb)
        Mask_prob = discriminator.forward(torch.Tensor(Hat_X).to(device), torch.Tensor(H_mb).to(device))
        
        loss = loss_computation(torch.Tensor(M_mb).to(device), torch.Tensor(X_mb).to(device), G_sample, Mask_prob, args.alpha_mse, mu, logvar)
        
        loss.backward(retain_graph=True)
        optimizer_G.step()
        optimizer_D.step()

    end = time.time() 
    

    start_test = time.time()
    generator.eval()
    a = [i for i in range(no)]
    batch_idx_ = np.array_split(a, args.batch_size)
    imputed_data_all = torch.Tensor([])
    for batch_idx in batch_idx_:
        X_mb = norm_data_x[batch_idx, :]  
        M_mb = data_m[batch_idx, :]  
        Z_mb = uniform_sampler(0, 0.01, len(batch_idx), dim)
        X_mb = M_mb * X_mb + (1-M_mb) * Z_mb
    
        imputed_data, mu, logvar = generator.forward(torch.Tensor(X_mb).to(device), torch.Tensor(M_mb).to(device))
        imputed_data = X_mb * M_mb + (1-M_mb) * imputed_data.cpu().detach().numpy()
        imputed_data_all = torch.cat((imputed_data_all, torch.Tensor(imputed_data)),dim=0)


    # Renormalization
    imputed_data = renormalization(imputed_data_all.cpu().detach().numpy(), norm_parameters)  
    
    end_test = time.time()
    

    # Rounding
    imputed_data = rounding(imputed_data, data_x) 

    print(f"==== Dataset: {args.data_name} ====")
    print(args)
    print(f"Train Time taken: {end - start}, Test Time taken: {end_test - start_test}")
    print(f"Missing Mechanism: {args.missing_mechanism}, miss_rate: {args.miss_rate}, RMSE: {np.round(RMSE(imputed_data, ori_data_x, data_m), 4)}, MAE: {np.round(MAE(imputed_data, ori_data_x, data_m), 4)}")

    norm_data_x, norm_parameters = normalization(imputed_data)
    


if __name__ == "__main__":
    args = parse_args()
    main(args)

