import numpy as np
from sklearn.impute import KNNImputer

def knn_imputation(xmiss):
    
    imputer = KNNImputer(n_neighbors=5)
    x_filled = imputer.fit_transform(xmiss)

    return x_filled