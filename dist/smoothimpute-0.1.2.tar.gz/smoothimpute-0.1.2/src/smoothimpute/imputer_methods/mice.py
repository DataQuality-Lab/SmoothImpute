import numpy as np
from fancyimpute import IterativeImputer

def mice_imputation(xmiss):
    
    x_filled = IterativeImputer().fit_transform(xmiss)

    return x_filled